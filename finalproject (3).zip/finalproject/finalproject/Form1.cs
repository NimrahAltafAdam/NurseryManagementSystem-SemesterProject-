﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace finalproject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            transparenttextboxtry.Form1 frm = new transparenttextboxtry.Form1();
            DialogResult selectButton = frm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PLANT_HEAVEN__WindowsFormsApp3_.Form1 form1 = new PLANT_HEAVEN__WindowsFormsApp3_.Form1();
            DialogResult selectButton = form1.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


            panel1.SendToBack();
            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);

            this.WindowState = FormWindowState.Maximized;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
